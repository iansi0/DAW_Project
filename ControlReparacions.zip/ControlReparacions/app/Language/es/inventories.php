<?php
return [
    "0"      => 'Placa Base',
    "1"      => 'Procesador',
    "2"      => 'Targeta Gráfica',
    "3"      => 'RAM',
    "4"      => 'Fuente alimentación',
    "5"      => 'Cableado',
    "6"      => 'Disco Duro',
    "7"      => 'Caja',
    "8"      => 'Mantenimiento',
    "9"      => 'Otros',
];