<?php
return [
    "0"      => 'Desguace',
    "1"      => 'Estropeado',
    "2"      => 'Estropeado-Recoger',
    "3"      => 'Estropeado-Enviado',
    "4"      => 'Estropeado-Entregado',
    "5"      => 'Espera-Reparación',
    "6"      => 'Reparación',
    "7"      => 'Revisión',
    "8"      => 'Reparado',
    "9"      => 'Reparado-Recoger',
    "10"     => 'Reparado-Enviado',
    "11"     => 'Finalizado',
    "12"     => 'SSTT',
    "13"     => 'Descartado',
];