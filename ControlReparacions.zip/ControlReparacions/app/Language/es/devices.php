<?php
return [
    "0"      => 'Portátil',
    "1"      => 'Torre',
    "2"      => 'Servidor',
    "3"      => 'Periférico',
    "4"      => 'Proyector',
    "5"      => 'Switch',
    "6"      => 'Tablet',
    "7"      => 'Móvil',
    "8"      => 'Enrutador',
    "9"      => 'Otros',
];