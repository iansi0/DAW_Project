<?php
return [
    'r_description'          => 'Descripcion requerida',
    'r_name_res'        => 'Nombre responsable requerido',
    'r_email_res'       => 'Email responsable requerido',
    'r_type_device'     => 'Tipo de dispositivo requerido',

];