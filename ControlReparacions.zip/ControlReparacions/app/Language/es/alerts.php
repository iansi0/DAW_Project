<?php
return [
    'yes_del'     => '¡Si, eliminalo!',
    'yes_upd'     => '¡Si, actualitzalo!',
    'cancel'    => 'Cancelar',

    'sure'      => '¿Estas seguro?',
    'sure_sub'      => 'Esta acción és irreversible.',

    'deleted'       => '¡Eliminado!',
    'updated'       => '¡Actualizado!',
    'deleted_sub'       => 'Se ha eliminado el registro.',
    'updated_sub'       => 'Se ha actualizado el registro.',
    
];