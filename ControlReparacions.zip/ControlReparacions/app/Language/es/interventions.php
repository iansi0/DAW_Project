<?php
return [
    "0"      => 'Normal',
    "1"      => 'Bloqueante'
];