<?php
return [
    'forget'    => '¿Has olvidado  la contraseña?',
    'remember'  => 'Recuerdame',
    'google'    => 'Google',
    'next'      => 'O inicia con',
    'text'      => 'No hay ningun centro asignado en esta cuenta xtec, por favor introduzca el codigo de centro en el que esta actualmente.',
];
