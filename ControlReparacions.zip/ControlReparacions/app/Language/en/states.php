<?php
return [
    "0"      => 'Scrap',
    "1"      => 'Broken',
    "2"      => 'Broken-Pick',
    "3"      => 'Broken-Send',
    "4"      => 'Broken-Delivered',
    "5"      => 'Waiting-Repair',
    "6"      => 'Repair',
    "7"      => 'Revision',
    "8"      => 'Fix',
    "9"      => 'Fix-Pick',
    "10"     => 'Fix-Send',
    "11"     => 'Done',
    "12"     => 'SSTT',
    "13"     => 'Discard',
];