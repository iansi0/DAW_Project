<?php
return [
    'r_description'          => 'Required description ',
    'r_name_res'        => 'Required responsible name',
    'r_email_res'       => 'Required responsible email',
    'r_type_device'     => 'Required device type',

];
