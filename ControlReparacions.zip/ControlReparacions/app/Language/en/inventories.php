<?php
return [
    "0"      => 'Motherboard',
    "1"      => 'CPU',
    "2"      => 'Garphic Card',
    "3"      => 'RAM',
    "4"      => 'Power Supply',
    "5"      => 'Wired',
    "6"      => 'Storage',
    "7"      => 'Case',
    "8"      => 'Maintenance',
    "9"      => 'Others',
];