<?php
return [
    "0"      => 'Laptop',
    "1"      => 'Desktop',
    "2"      => 'Server',
    "3"      => 'Peripheral',
    "4"      => 'Projector',
    "5"      => 'Switch',
    "6"      => 'Tablet',
    "7"      => 'Phone',
    "8"      => 'Router',
    "9"      => 'Others',
];