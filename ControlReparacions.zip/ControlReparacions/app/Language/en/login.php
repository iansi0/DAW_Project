<?php
return [
    'forget' => 'Forgot password?',
];
