<?php
return [
    'forget'    => 'Has oblidat la contrasenya?',
    'remember'  => 'Recorda\'m',
    'google'    => 'Google',
    'next'      => 'O inicia amb',
    'text'      => 'No hi ha registre de cap centre assignat en aquest compte xtec, si us plau introdueix el codi de centre que estàs actualment.',
];
