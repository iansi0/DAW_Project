<?php
return [
    "0"      => 'Portàtil',
    "1"      => 'Sobretaula',
    "2"      => 'Servidor',
    "3"      => 'Perifèric',
    "4"      => 'Projector',
    "5"      => 'Switch',
    "6"      => 'Tablet',
    "7"      => 'Móvil',
    "8"      => 'Enrutador',
    "9"      => 'Altres',
];