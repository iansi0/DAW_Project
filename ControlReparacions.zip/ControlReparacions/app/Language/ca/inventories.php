<?php
return [
    "0"      => 'Placa Base',
    "1"      => 'Processador',
    "2"      => 'Targeta Gràfica',
    "3"      => 'RAM',
    "4"      => 'Font alimentació',
    "5"      => 'Cablejat',
    "6"      => 'Disc Dur',
    "7"      => 'Caixa',
    "8"      => 'Manteniment',
    "9"      => 'Altres',
];