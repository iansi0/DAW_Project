<?php
return [
    'r_description'          => 'Descripció requerit',
    'r_name_res'        => 'Nom responsable requerit',
    'r_email_res'       => 'Email responsable requerit',
    'r_type_device'     => 'Tipus de dispositiu requerit',

];