<?php
return [
    "0"      => 'Desguaçat ',
    "1"      => 'Espatllat',
    "2"      => 'Espatllat-Recollir',
    "3"      => 'Espatllat-Enviat',
    "4"      => 'Espatllat-Entregat',
    "5"      => 'Espera-Reparació',
    "6"      => 'Reparació',
    "7"      => 'Revisió',
    "8"      => 'Reparat',
    "9"      => 'Reparat-Recollir',
    "10"     => 'Reparat-Enviat',
    "11"     => 'Finalitzat',
    "12"     => 'SSTT',
    "13"     => 'Rebutjat',
];