<?php
return [
    'comarca'     => 'Tiquets per comarca',
    'type'    => 'Tiquets per tipus',
    'month'    => 'Tiquets per mes',
    'state'    => 'Tiquets per estat',
    'cost'    => 'Gastos per centre emissor',

];